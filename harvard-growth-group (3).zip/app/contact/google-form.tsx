import Image from "next/image"

export default function ContactGoogleForm() {
  return (
    <div className="container mx-auto px-6 py-12">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <Image
            src="/images/hugg-logo-transparent.png"
            alt="HUGG Logo"
            width={180}
            height={72}
            className="h-16 w-auto mx-auto mb-6"
          />
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-hugg-green">Contact Us</h1>
          <p className="text-xl max-w-2xl mx-auto mb-8">
            Interested in partnering with us or have any questions? We'd love to hear from you!
          </p>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <iframe
              src="https://docs.google.com/forms/d/e/YOUR_GOOGLE_FORM_ID/viewform?embedded=true"
              width="100%"
              height="800"
              className="border-0"
              title="Contact Form"
            >
              Loading…
            </iframe>
          </div>
        </div>
      </div>
    </div>
  )
}

