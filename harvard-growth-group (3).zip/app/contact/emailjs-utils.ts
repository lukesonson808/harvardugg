// This is a client-side utility for sending emails using EmailJS
// You would need to sign up for a free EmailJS account and configure a template

export async function sendContactEmail(data: {
  name: string
  email: string
  company?: string
  message: string
}) {
  const serviceId = "your_emailjs_service_id" // Replace with your EmailJS service ID
  const templateId = "your_emailjs_template_id" // Replace with your EmailJS template ID
  const userId = "your_emailjs_user_id" // Replace with your EmailJS user ID

  const templateParams = {
    from_name: data.name,
    from_email: data.email,
    company: data.company || "Not provided",
    message: data.message,
    to_email: "harvardugg@gmail.com",
  }

  try {
    const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        service_id: serviceId,
        template_id: templateId,
        user_id: userId,
        template_params: templateParams,
      }),
    })

    if (response.ok) {
      return { success: true }
    } else {
      throw new Error("Failed to send email")
    }
  } catch (error) {
    console.error("Error sending email:", error)
    throw error
  }
}

