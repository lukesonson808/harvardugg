import Image from "next/image"
import { Mail, MapPin, ExternalLink } from "lucide-react"

export default function ContactSimple() {
  return (
    <div className="container mx-auto px-6 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <Image
            src="/images/hugg-logo-transparent.png"
            alt="HUGG Logo"
            width={180}
            height={72}
            className="h-16 w-auto mx-auto mb-6"
          />
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-hugg-green">Contact Us</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Interested in partnering with us or have any questions? We'd love to hear from you!
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-lg shadow-md border-t-4 border-hugg-green">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 rounded-full bg-hugg-green/10 flex items-center justify-center mr-4">
                <Mail className="h-6 w-6 text-hugg-green" />
              </div>
              <div>
                <h2 className="text-2xl font-semibold text-hugg-green">Email Us</h2>
                <p className="text-gray-600">We'll respond within 24-48 hours</p>
              </div>
            </div>
            <a
              href="mailto:harvardugg@gmail.com"
              className="block w-full py-3 px-4 bg-hugg-green text-white text-center rounded-md hover:bg-opacity-90 transition-colors"
            >
              Email harvardugg@gmail.com
            </a>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-md border-t-4 border-hugg-green">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 rounded-full bg-hugg-green/10 flex items-center justify-center mr-4">
                <ExternalLink className="h-6 w-6 text-hugg-green" />
              </div>
              <div>
                <h2 className="text-2xl font-semibold text-hugg-green">Google Form</h2>
                <p className="text-gray-600">Submit your inquiry via our form</p>
              </div>
            </div>
            <a
              href="https://forms.gle/exampleFormLink"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full py-3 px-4 bg-hugg-green text-white text-center rounded-md hover:bg-opacity-90 transition-colors"
            >
              Fill Out Our Form
            </a>
          </div>
        </div>

        <div className="mt-12 bg-white p-8 rounded-lg shadow-md">
          <div className="flex items-start mb-6">
            <div className="w-12 h-12 rounded-full bg-hugg-green/10 flex items-center justify-center mr-4 mt-1">
              <MapPin className="h-6 w-6 text-hugg-green" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold text-hugg-green">Our Location</h2>
              <p className="text-gray-600 mt-2">
                Harvard University
                <br />
                Cambridge, MA 02138
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

