"use client"

import { useState } from "react"
import Image from "next/image"

const teamMembers = [
  {
    name: "Luke Sonson",
    role: "President",
    image: "/images/luke-sonson.jpeg",
    bio: "Luke is a sophomore at Harvard concentrating in Applied Mathematics and Economics, and currently resides in Leverett House. He is the founder and president of the Harvard Undergraduate Growth Group, driven by a passion for helping startups scale and innovate. Outside of school and HUGG, Luke enjoys surfing, giving haircuts, and plays rugby for the Harvard club team.",
  },
  {
    name: "Louis Murray",
    role: "Vice President",
    image: "/images/louis-murray.jpeg",
    bio: "Louis oversees operations and strategy development, ensuring our consulting teams deliver exceptional value to clients.",
  },
  {
    name: "Samip Phuyal",
    role: "Treasurer",
    image: "/images/samip-phuyal.png",
    bio: "Samip manages the financial aspects of HUGG, ensuring resources are allocated effectively to maximize our impact.",
  },
  {
    name: "Tomas Gonzalez",
    role: "Secretary",
    image: "/images/tomas-gonzalez.jpeg",
    bio: "Tomas handles administrative responsibilities for HUGG, managing communications, organizing meetings, and ensuring smooth operations across all our initiatives.",
  },
]

export default function Team() {
  const [expandedBio, setExpandedBio] = useState<number | null>(null)

  const toggleBio = (index: number) => {
    if (expandedBio === index) {
      setExpandedBio(null)
    } else {
      setExpandedBio(index)
    }
  }

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold mb-4 text-hugg-green">Our Team</h1>
        <p className="text-xl max-w-3xl mx-auto">
          Meet the dedicated leaders of the Harvard Undergraduate Growth Group who are passionate about connecting
          Harvard talent with innovative startups.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 max-w-6xl mx-auto">
        {teamMembers.map((member, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="h-80 relative">
              <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
            </div>
            <div className="p-6">
              <h2 className="text-2xl font-semibold text-hugg-green">{member.name}</h2>
              <p className="text-gray-600 mb-4">{member.role}</p>

              <button
                onClick={() => toggleBio(index)}
                className="w-full py-2 px-4 bg-hugg-green/10 text-hugg-green rounded-md hover:bg-hugg-green/20 transition-colors text-sm font-medium flex items-center justify-center"
              >
                {expandedBio === index ? "Hide Bio" : "View Bio"}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className={`h-4 w-4 ml-1 transition-transform ${expandedBio === index ? "rotate-180" : ""}`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {expandedBio === index && <div className="mt-4 text-gray-700 animate-fadeIn">{member.bio}</div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

