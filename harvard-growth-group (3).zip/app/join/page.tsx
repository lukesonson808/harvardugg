import ScrollAnimation from "@/components/scroll-animation"

export default function Join() {
  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold mb-4 text-hugg-green">Join Harvard Undergraduate Growth Group</h1>
        <p className="text-xl max-w-3xl mx-auto">
          We're looking for talented and passionate Harvard undergraduates to join our team and make a real impact.
        </p>
      </div>

      <div className="max-w-4xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 mb-16">
          <ScrollAnimation>
            <div className="bg-white p-8 rounded-lg shadow-md border-t-4 border-hugg-green">
              <h2 className="text-2xl font-semibold mb-6 text-hugg-green">Why Join Us?</h2>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-hugg-green/20 flex items-center justify-center mt-1 mr-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-hugg-green"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <p>Gain real-world consulting experience working with startups</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-hugg-green/20 flex items-center justify-center mt-1 mr-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-hugg-green"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <p>Develop valuable skills in strategy, marketing, and financial analysis</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-hugg-green/20 flex items-center justify-center mt-1 mr-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-hugg-green"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <p>Build a network of like-minded peers and industry professionals</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-hugg-green/20 flex items-center justify-center mt-1 mr-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-hugg-green"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <p>Make a tangible impact on growing businesses</p>
                </li>
              </ul>
            </div>
          </ScrollAnimation>

          <ScrollAnimation delay={1}>
            <div className="bg-white p-8 rounded-lg shadow-md border-t-4 border-hugg-green">
              <h2 className="text-2xl font-semibold mb-6 text-hugg-green">What We Look For</h2>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-hugg-green/20 flex items-center justify-center mt-1 mr-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-hugg-green"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <p>Passion for entrepreneurship and innovation</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-hugg-green/20 flex items-center justify-center mt-1 mr-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-hugg-green"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <p>Strong analytical and problem-solving abilities</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-hugg-green/20 flex items-center justify-center mt-1 mr-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-hugg-green"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <p>Excellent communication and teamwork skills</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-hugg-green/20 flex items-center justify-center mt-1 mr-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-hugg-green"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <p>Commitment to delivering high-quality work</p>
                </li>
              </ul>
            </div>
          </ScrollAnimation>
        </div>

        <ScrollAnimation>
          <div className="bg-gray-50 p-8 rounded-lg shadow-md mb-12">
            <h2 className="text-2xl font-semibold mb-4 text-hugg-green">Application Process</h2>
            <ol className="space-y-4 list-decimal list-inside">
              <li className="pl-2">Complete our online application form</li>
              <li className="pl-2">Attend our workshops and networking events to learn more about HUGG</li>
              <li className="pl-2">Selected candidates will be invited for a first-round interview</li>
              <li className="pl-2">Final round may include a case study or project</li>
              <li className="pl-2">Receive decision and onboarding information</li>
            </ol>
            <div className="mt-4 bg-hugg-green/10 p-4 rounded-md">
              <p className="text-hugg-green font-medium">
                We host various workshops and networking events throughout the semester to help you learn more about our
                work and meet current members before the interview process begins.
              </p>
            </div>
          </div>
        </ScrollAnimation>

        <div className="text-center">
          <a
            href="https://forms.gle/McoJ1DAWA5XgCxJ6A"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-4 bg-hugg-green text-white font-semibold rounded-md hover:bg-opacity-90 transition-all duration-300 text-lg"
          >
            Apply Now
          </a>
          <p className="mt-4 text-gray-600">
            We encourage you to apply early to participate in all our pre-interview events!
          </p>
        </div>
      </div>
    </div>
  )
}

