export default function Projects() {
  return (
    <div className="container mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold mb-6 text-hugg-green">Our Projects</h1>
      <p className="text-xl mb-8">
        We're currently working on exciting projects. Check back soon to see our portfolio of work!
      </p>
      <div className="bg-gray-100 p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-semibold mb-4 text-hugg-green">Coming Soon</h2>
        <p>
          Our team is diligently working on various projects to help startups scale and grow. We'll be updating this
          page with case studies and success stories in the near future.
        </p>
      </div>
    </div>
  )
}

