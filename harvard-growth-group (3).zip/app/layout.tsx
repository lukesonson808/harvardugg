import type React from "react"
import type { Metadata } from "next"
import { Playfair_Display, Cormorant_Garamond } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
})

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  variable: "--font-cormorant",
  weight: ["300", "400", "500", "600", "700"],
})

export const metadata: Metadata = {
  title: "Harvard Undergraduate Growth Group",
  description:
    "Helping startups scale and grow through strategic consulting, market analysis, and innovative solutions.",
  icons: {
    icon: [
      { url: "/favicon.ico" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    shortcut: ["/favicon.ico"],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    other: [
      {
        rel: "mask-icon",
        url: "/favicon.ico",
      },
    ],
  },
  manifest: "/site.webmanifest",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://harvard-growth-group.vercel.app/",
    title: "Harvard Undergraduate Growth Group",
    description:
      "Helping startups scale and grow through strategic consulting, market analysis, and innovative solutions.",
    siteName: "Harvard Undergraduate Growth Group",
    images: [
      {
        url: "/images/hugg-logo-main.png",
        width: 800,
        height: 600,
        alt: "Harvard Undergraduate Growth Group Logo",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Harvard Undergraduate Growth Group",
    description:
      "Helping startups scale and grow through strategic consulting, market analysis, and innovative solutions.",
    images: ["/images/hugg-logo-main.png"],
  },
  robots: {
    index: true,
    follow: true,
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <meta name="msapplication-TileImage" content="/favicon.ico" />
        <meta name="msapplication-TileColor" content="#2D6E63" />
        <meta name="theme-color" content="#2D6E63" />
      </head>
      <body className={`${playfair.variable} ${cormorant.variable} font-cormorant`}>
        <Header />
        <main className="pt-14">{children}</main>
        <Footer />
      </body>
    </html>
  )
}



import './globals.css'