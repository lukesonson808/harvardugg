import Link from "next/link"
import Image from "next/image"
import ScrollAnimation from "@/components/scroll-animation"

export default function Home() {
  return (
    <div>
      {/* Hero Section with Image Overlay */}
      <section className="relative h-screen">
        <Image src="/images/harvard-yard.jpeg" alt="Harvard Yard" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-gradient-to-b from-hugg-green/70 to-hugg-green/90 flex flex-col items-center justify-center text-white px-4 text-center">
          <div className="flex flex-col h-full justify-center items-center">
            <div className="mb-auto"></div> {/* Spacer to push content to center */}
            <ScrollAnimation>
              <h1 className="text-5xl md:text-7xl font-bold mb-4 tracking-tight">Harvard Undergraduate Growth Group</h1>
            </ScrollAnimation>
            <ScrollAnimation delay={1}>
              <p className="text-xl md:text-2xl max-w-3xl mx-auto font-light italic mb-16">
                Empowering startups to scale through strategic consulting, market analysis, and innovative solutions
              </p>
            </ScrollAnimation>
            <ScrollAnimation delay={2} className="mt-16">
              <Link
                href="/contact"
                className="px-8 py-3 bg-white text-hugg-green rounded-md hover:bg-gray-100 transition-all duration-300 text-lg font-semibold"
              >
                Partner With Us
              </Link>
            </ScrollAnimation>
            <div className="mt-auto"></div> {/* Spacer to push content to center */}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-hugg-green">Our Mission</h2>
          </ScrollAnimation>

          <div className="max-w-4xl mx-auto">
            <ScrollAnimation>
              <p className="text-xl md:text-2xl mb-8 leading-relaxed">
                The Harvard Undergraduate Growth Group is a premier student-led organization dedicated to bridging the
                gap between Harvard's intellectual capital and the dynamic world of startups and emerging businesses.
              </p>
            </ScrollAnimation>

            <ScrollAnimation delay={1}>
              <p className="text-lg md:text-xl mb-8 leading-relaxed">
                We believe in the power of collaboration between academic excellence and entrepreneurial innovation. Our
                mission is to provide comprehensive strategic consulting services to startups at critical stages of
                their development, helping them navigate challenges, identify opportunities, and implement effective
                growth strategies.
              </p>
            </ScrollAnimation>

            <ScrollAnimation delay={2}>
              <p className="text-lg md:text-xl leading-relaxed">
                Through rigorous analysis, creative problem-solving, and leveraging Harvard's vast resources, we aim to
                catalyze sustainable growth for our partners while offering our members unparalleled real-world
                experience in business strategy and entrepreneurship.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <ScrollAnimation>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-hugg-green">Our Services</h2>
          </ScrollAnimation>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <ScrollAnimation className="bg-white p-8 rounded-lg shadow-md border-t-4 border-hugg-green">
              <h3 className="text-2xl font-semibold mb-4 text-hugg-green">Full-Funnel Growth Support</h3>
              <p className="text-lg">
                We help startups identify and improve key growth levers across the entire user journey — from awareness
                to retention. Whether it's redesigning landing pages, refining messaging, or analyzing churn, we're
                hands-on wherever we're needed.
              </p>
            </ScrollAnimation>

            <ScrollAnimation delay={1} className="bg-white p-8 rounded-lg shadow-md border-t-4 border-hugg-green">
              <h3 className="text-2xl font-semibold mb-4 text-hugg-green">Lean, Experiment-Driven Mindset</h3>
              <p className="text-lg">
                We bring a fast-paced, test-and-learn approach. We rapidly design and run experiments (A/B tests,
                channel pilots, user feedback loops) to validate ideas and uncover what actually drives results —
                without burning through time or budget.
              </p>
            </ScrollAnimation>

            <ScrollAnimation delay={2} className="bg-white p-8 rounded-lg shadow-md border-t-4 border-hugg-green">
              <h3 className="text-2xl font-semibold mb-4 text-hugg-green">Cross-Functional Hustle</h3>
              <p className="text-lg">
                Our team blends skills across product, marketing, design, and analytics. Need help setting up email drip
                campaigns? Scraping leads? Building a pitch deck? We're generalists who learn fast and aren't afraid to
                get our hands dirty.
              </p>
            </ScrollAnimation>

            <ScrollAnimation delay={3} className="bg-white p-8 rounded-lg shadow-md border-t-4 border-hugg-green">
              <h3 className="text-2xl font-semibold mb-4 text-hugg-green">Unmatched Energy & Curiosity</h3>
              <p className="text-lg">
                We bring the kind of intensity and creativity only college students can: fresh eyes, zero ego, and a
                willingness to take on the projects others overlook. We'll dive into anything — and we care deeply about
                helping founders win.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation>
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-hugg-green">Ready to Accelerate Your Growth?</h2>
          </ScrollAnimation>

          <ScrollAnimation delay={1}>
            <p className="text-xl max-w-3xl mx-auto mb-12">
              Whether you're a pre-seed startup or scaling your operations, our team of Harvard undergraduates is ready
              to help you navigate your next phase of growth.
            </p>
          </ScrollAnimation>

          <ScrollAnimation delay={2}>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/contact"
                className="px-8 py-3 bg-hugg-green text-white font-semibold rounded-md hover:bg-opacity-90 transition-all duration-300 text-lg"
              >
                Partner With Us
              </Link>
              <Link
                href="/projects"
                className="px-8 py-3 border-2 border-hugg-green text-hugg-green font-semibold rounded-md hover:bg-hugg-green hover:text-white transition-all duration-300 text-lg"
              >
                View Our Work
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  )
}

