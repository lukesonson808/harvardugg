"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white shadow-md fixed w-full z-50">
      <nav className="container mx-auto px-6 py-2">
        <div className="flex items-center justify-between">
          <div className="text-xl font-bold">
            <Link href="/" className="flex items-center">
              <Image
                src="/images/hugg-logo-main.png"
                alt="HUGG Logo"
                width={150}
                height={60}
                className="h-10 w-auto"
                priority
              />
              <span className="sr-only">Harvard Undergraduate Growth Group</span>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-700 focus:outline-none">
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Desktop menu */}
          <div className="hidden md:flex space-x-8">
            <Link href="/" className="font-playfair text-gray-800 hover:text-hugg-green transition-colors">
              Home
            </Link>
            <Link href="/projects" className="font-playfair text-gray-800 hover:text-hugg-green transition-colors">
              Projects
            </Link>
            <Link href="/team" className="font-playfair text-gray-800 hover:text-hugg-green transition-colors">
              Team
            </Link>
            <Link href="/join" className="font-playfair text-gray-800 hover:text-hugg-green transition-colors">
              Join Us
            </Link>
            <Link href="/contact" className="font-playfair text-gray-800 hover:text-hugg-green transition-colors">
              Contact
            </Link>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 space-y-4">
            <Link
              href="/"
              className="block font-playfair text-gray-800 hover:text-hugg-green transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/projects"
              className="block font-playfair text-gray-800 hover:text-hugg-green transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Projects
            </Link>
            <Link
              href="/team"
              className="block font-playfair text-gray-800 hover:text-hugg-green transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Team
            </Link>
            <Link
              href="/join"
              className="block font-playfair text-gray-800 hover:text-hugg-green transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Join Us
            </Link>
            <Link
              href="/contact"
              className="block font-playfair text-gray-800 hover:text-hugg-green transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </Link>
          </div>
        )}
      </nav>
    </header>
  )
}

