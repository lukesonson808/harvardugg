import Link from "next/link"
import Image from "next/image"

export default function Footer() {
  return (
    <footer className="bg-hugg-green text-white py-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="mb-4 bg-white inline-block p-2 rounded">
              <Image
                src="/images/hugg-logo-main.png"
                alt="HUGG Logo"
                width={150}
                height={60}
                className="h-12 w-auto"
                priority
              />
            </div>
            <p className="text-gray-200 mb-4">
              Empowering startups to scale through strategic consulting, market analysis, and innovative solutions.
            </p>
            <p className="text-gray-200">© {new Date().getFullYear()} Harvard Undergraduate Growth Group</p>
          </div>

          <div>
            <h4 className="text-xl font-playfair font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-200 hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/projects" className="text-gray-200 hover:text-white transition-colors">
                  Projects
                </Link>
              </li>
              <li>
                <Link href="/team" className="text-gray-200 hover:text-white transition-colors">
                  Team
                </Link>
              </li>
              <li>
                <Link href="/join" className="text-gray-200 hover:text-white transition-colors">
                  Join Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-200 hover:text-white transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xl font-playfair font-bold mb-4">Contact Us</h4>
            <address className="not-italic text-gray-200 space-y-2">
              <p>Harvard University</p>
              <p>Cambridge, MA 02138</p>
              <p>
                Email:{" "}
                <a href="mailto:harvardugg@gmail.com" className="hover:text-white transition-colors">
                  harvardugg@gmail.com
                </a>
              </p>
            </address>
          </div>
        </div>
      </div>
    </footer>
  )
}

