# Contact Form Setup Instructions

This document provides instructions for setting up the contact form to send emails to harvardugg@gmail.com.

## Option 1: Formspree (Recommended - Easiest)

1. Go to [Formspree.io](https://formspree.io) and sign up for a free account
2. Create a new form and link it to harvardugg@gmail.com
3. Copy the form ID (it looks like "xyyqgpnz")
4. Replace the `FORMSPREE_FORM_ID` in `app/contact/formspree.tsx` with your form ID
5. Rename `formspree.tsx` to `page.tsx` to use it as your contact page

Benefits:
- Free for up to 50 submissions per month
- No coding required
- Spam protection
- Email notifications
- Dashboard to view submissions

## Option 2: EmailJS

1. Go to [EmailJS.com](https://www.emailjs.com) and sign up for a free account
2. Create an Email Service (Gmail is recommended)
3. Create an Email Template with the following variables:
   - `from_name`
   - `from_email`
   - `company`
   - `message`
4. Get your Service ID, Template ID, and Public Key
5. Replace the placeholders in `app/contact/page.tsx`:
   - `EMAILJS_SERVICE_ID`
   - `EMAILJS_TEMPLATE_ID`
   - `EMAILJS_PUBLIC_KEY`

Benefits:
- Free for up to 200 emails per month
- Client-side only (no server required)
- Customizable email templates
- Spam protection

## Option 3: Web3Forms

1. Go to [Web3Forms.com](https://web3forms.com) and sign up for a free account
2. Get your API Key
3. Replace the `WEB3FORMS_API_KEY` in `app/contact/web3forms.tsx` with your API Key
4. Rename `web3forms.tsx` to `page.tsx` to use it as your contact page

Benefits:
- Free for unlimited submissions
- No server-side code needed
- Spam protection with reCAPTCHA
- Email notifications

